# web-scraping
Beautiful Soup web scraping tutorial. <br/>

Link to video: https://youtu.be/GjKQ6V_ViQE

The websites we use as examples to scrape from are <br/>
https://keithgalli.github.io/web-scraping/example.html <br/>
https://keithgalli.github.io/web-scraping/webpage.html
